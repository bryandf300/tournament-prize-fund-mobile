(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const fields = ['name','date','location','director','entries','fee','lineage','expenses','added','places','curve','topCount','roundWhole'];
  const numeric = new Set(['entries','fee','lineage','expenses','added','places','curve','topCount']);
  const STORAGE_KEY = 'tpfMobileRecords_v2';
  const money = n => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number.isFinite(n) ? n : 0);
  let records = [], currentId = null, payouts = [], saveTimer = null;

  function makeId(){ return (crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
  function localDate(){ const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
  function blank(){ return {id:makeId(),name:'New Tournament',date:localDate(),location:'',director:'',entries:100,fee:30,lineage:10,expenses:0,added:0,places:10,curve:5,topCount:3,roundWhole:false}; }
  function saySaved(message){ $('saveStatus').textContent = message; }
  function readStore(){
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if(raw){ const parsed = JSON.parse(raw); if(Array.isArray(parsed)) records = parsed.filter(r => r && r.id); }
      // Import records from v1 if this is the first v2 launch.
      if(!records.length){
        const old = JSON.parse(localStorage.getItem('tpfMobileRecords') || '[]');
        if(Array.isArray(old) && old.length) records = old.filter(r => r && r.id);
      }
    } catch(e) { records = []; saySaved('Storage unavailable — keep this page open and export backups.'); }
    if(!records.length) records = [blank()];
    currentId = records[0].id;
    persist(false);
    renderSelect(); loadRecord(records[0]);
  }
  function readForm(){
    const old = records.find(r => r.id === currentId) || {};
    const r = {...old,id:currentId};
    for(const f of fields){
      const el = $(f);
      r[f] = f === 'roundWhole' ? el.checked : numeric.has(f) ? Number(el.value || 0) : el.value.trim();
    }
    r.entries = Math.max(1, Math.min(10000, Math.floor(r.entries || 1)));
    r.places = Math.max(1, Math.min(r.entries, Math.floor(r.places || 1)));
    r.topCount = Math.max(1, Math.min(r.entries, Math.floor(r.topCount || 1)));
    r.curve = Math.max(1, Math.min(10, Math.floor(r.curve || 1)));
    for(const f of ['fee','lineage','expenses','added']) r[f] = Math.max(0, Number.isFinite(r[f]) ? r[f] : 0);
    return r;
  }
  function persist(show=true){
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
      // Keep a copy under the v1 key for easier recovery when updating versions.
      localStorage.setItem('tpfMobileRecords', JSON.stringify(records));
      if(show) saySaved(`Saved on this phone · ${new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}`);
      return true;
    } catch(e) { saySaved('Could not save. Browser storage may be full or blocked.'); return false; }
  }
  function saveCurrent(show=true){
    if(!currentId) return null;
    const r = readForm(); const i = records.findIndex(x=>x.id===currentId);
    if(i<0) records.unshift(r); else records[i]=r;
    persist(show); renderSelect(); return r;
  }
  function queueSave(){
    saySaved('Saving…'); clearTimeout(saveTimer);
    saveTimer = setTimeout(()=>{ saveCurrent(true); calculate(false); }, 180);
  }
  function renderSelect(){
    const select=$('tournamentSelect'), previous=currentId;
    select.replaceChildren();
    records.forEach(r=>{const o=document.createElement('option');o.value=r.id;o.textContent=r.name||'Untitled tournament';select.append(o)});
    select.value=previous || records[0]?.id || '';
  }
  function loadRecord(r){
    currentId=r.id;
    fields.forEach(f=>{if(f==='roundWhole')$(f).checked=!!r[f];else $(f).value=r[f] ?? ''});
    renderSelect(); calculate(false); saySaved('Tournament loaded');
  }
  function calculate(save=true){
    const r = save ? saveCurrent(false) : readForm(); if(!r) return;
    const entries=Math.max(1,r.entries), places=Math.max(1,Math.min(entries,r.places));
    $('places').max=entries; $('topCount').max=entries;
    if(Number($('places').value)>entries) $('places').value=entries;
    if(Number($('topCount').value)>entries) $('topCount').value=entries;
    $('topValue').textContent=$('topCount').value; $('curveValue').textContent=`${$('curve').value} / 10`;
    const collected=entries*r.fee;
    const expenses=entries*r.lineage+r.expenses;
    const fund=Math.max(0,collected-expenses+r.added);
    $('collected').textContent=money(collected); $('expenseTotal').textContent=money(expenses);
    $('addedTotal').textContent=money(r.added); $('fund').textContent=money(fund);
    const curve=Math.max(1,Math.min(10,r.curve));
    const top=Math.max(1,Math.min(places,r.topCount));
    // Loan-style curve: a smooth decreasing power distribution. Higher curve = more weight at the top.
    const exponent=0.35+(curve-1)*0.23;
    let weights=Array.from({length:places},(_,i)=>1/Math.pow(i+1,exponent));
    // The second slider emphasizes the selected top positions while preserving a descending curve.
    const boost=1+(curve-1)*0.035;
    weights=weights.map((w,i)=>w*(i<top?Math.pow(boost,top-i):1));
    const totalWeight=weights.reduce((a,b)=>a+b,0)||1;
    let amounts=weights.map(w=>fund*w/totalWeight);
    if(r.roundWhole && places>1){
      let used=0;
      for(let i=0;i<places-1;i++){ amounts[i]=Math.floor(amounts[i]); used+=amounts[i]; }
      amounts[places-1]=Math.max(0,Math.round((fund-used)*100)/100);
    } else if(places){
      let used=0; amounts=amounts.map((a,i)=>{ if(i===places-1)return 0; const v=Math.round(a*100)/100;used+=v;return v; });
      amounts[places-1]=Math.max(0,Math.round((fund-used)*100)/100);
    }
    payouts=amounts.map((amount,i)=>({place:i+1,amount,percent:fund>0?amount/fund*100:weights[i]/totalWeight*100}));
    const tbody=$('payoutRows');tbody.replaceChildren();
    payouts.forEach(p=>{const tr=document.createElement('tr');const ord=p.place===1?'1st':p.place===2?'2nd':p.place===3?'3rd':`${p.place}th`;
      [ord,`${p.percent.toFixed(2)}%`,money(p.amount)].forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;if(i===2)td.className='currency';tr.append(td)});tbody.append(tr);});
    const paid=amounts.reduce((a,b)=>a+b,0);$('paid').textContent=money(paid);$('unallocated').textContent=money(fund-paid);
    $('status').textContent='';
  }
  function newRecord(){saveCurrent(false);const r=blank();records.unshift(r);currentId=r.id;loadRecord(r);$('name').focus();persist(true);}
  $('newBtn').addEventListener('click',newRecord);
  $('tournamentSelect').addEventListener('change',e=>{const selectedId=e.target.value;saveCurrent(false);const r=records.find(x=>x.id===selectedId);if(r)loadRecord(r)});
  $('duplicateBtn').addEventListener('click',()=>{const r=saveCurrent(false);const copy={...r,id:makeId(),name:`${r.name||'Tournament'} Copy`};records.unshift(copy);loadRecord(copy);persist(true)});
  $('deleteBtn').addEventListener('click',()=>{
    const r=records.find(x=>x.id===currentId);if(!r)return;
    if(!confirm(`Delete “${r.name||'Untitled tournament'}”? This cannot be undone.`))return;
    records=records.filter(x=>x.id!==currentId);if(!records.length)records=[blank()];currentId=records[0].id;loadRecord(records[0]);persist(true);
  });
  fields.forEach(f=>$(f).addEventListener('input',()=>{calculate(false);queueSave()}));
  $('saveBtn').addEventListener('click',()=>{clearTimeout(saveTimer);saveCurrent(true);calculate(false)});
  $('exportBtn').addEventListener('click',()=>{
    const r=saveCurrent(false);const rows=[['Tournament',r.name],['Date',r.date],['Location',r.location],['Director',r.director],['Entries',r.entries],['Entry fee',r.fee],['Lineage per entry',r.lineage],['Other expenses',r.expenses],['Added money',r.added],['Available prize fund',$('fund').textContent],[],['Place','Percent','Payout'],...payouts.map(p=>[p.place,p.percent.toFixed(2)+'%',p.amount.toFixed(2)])];
    const csv=rows.map(row=>row.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\r\n');
    const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=(r.name||'tournament').replace(/[^a-z0-9-_]+/gi,'_')+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  window.addEventListener('pagehide',()=>{clearTimeout(saveTimer);saveCurrent(false)});
  if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  readStore();
})();
