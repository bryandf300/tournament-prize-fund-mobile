# Tournament Prize Fund Calculator Mobile v2

Mobile-first Progressive Web App for Android Chrome and desktop browsers. Licensing is not included or enabled.

## Features
- Multiple independent tournament records
- Autosaves edits to browser storage on this device
- Entry fee, lineage, other expenses, added money, entries, places paid
- Live prize-fund calculations
- Payout curve and higher-payout-position sliders
- Optional whole-dollar payout rounding; final place receives the remainder
- CSV export
- Offline app shell after first visit when hosted over HTTPS

## Test the math
Default test: 100 entries, $30 entry fee, $10 lineage per entry, $0 other expenses, $0 added money.
- Total collected: $3,000.00
- Expenses: $1,000.00
- Available prize fund: $2,000.00

## Install on Android
1. Publish the contents of this folder to a static host with HTTPS (for example GitHub Pages).
2. Open the HTTPS site in Chrome on Android.
3. Use Chrome menu > Install app or Add to Home screen.
4. Add a tournament, change values, tap Save tournament, close/reopen the app, and confirm the values remain.

Records are stored locally in the browser on this device. They do not sync to the Windows desktop application or other phones. Clearing Chrome site data can remove records; use Export CSV for a backup.
